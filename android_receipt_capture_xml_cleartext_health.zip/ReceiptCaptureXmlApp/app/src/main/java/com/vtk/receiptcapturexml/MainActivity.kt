package com.vtk.receiptcapturexml

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var serverIpEditText: EditText
    private lateinit var serverPortEditText: EditText
    private lateinit var statusTextView: TextView
    private lateinit var resultTextView: TextView
    private lateinit var imagePreview: ImageView
    private var latestPhotoFile: File? = null
    private var latestPhotoUri: Uri? = null
    private val client = OkHttpClient()

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            launchCameraIntent()
        } else {
            toast("Camera permission denied")
        }
    }

    private val takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) {
            val file = latestPhotoFile
            if (file != null && file.exists()) {
                imagePreview.setImageBitmap(BitmapFactory.decodeFile(file.absolutePath))
                statusTextView.text = "Photo captured: ${file.name}"
                resultTextView.text = file.absolutePath
            } else {
                statusTextView.text = "Photo capture failed"
            }
        } else {
            statusTextView.text = "Photo capture cancelled"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        serverIpEditText = findViewById(R.id.serverIpEditText)
        serverPortEditText = findViewById(R.id.serverPortEditText)
        statusTextView = findViewById(R.id.statusTextView)
        resultTextView = findViewById(R.id.resultTextView)
        imagePreview = findViewById(R.id.imagePreview)

        findViewById<Button>(R.id.checkServerButton).setOnClickListener { checkServerHealth() }
        findViewById<Button>(R.id.captureButton).setOnClickListener {
            if (hasCameraPermission()) {
                launchCameraIntent()
            } else {
                permissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
        findViewById<Button>(R.id.uploadButton).setOnClickListener { uploadLatestPhoto() }
    }

    private fun hasCameraPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }

    private fun launchCameraIntent() {
        val file = File(cacheDir, "receipt_${System.currentTimeMillis()}.jpg")
        latestPhotoFile = file
        val uri = FileProvider.getUriForFile(this, "${packageName}.provider", file)
        latestPhotoUri = uri
        takePictureLauncher.launch(uri)
        statusTextView.text = "Opening camera..."
    }

    private fun baseUrl(): String {
        val ip = serverIpEditText.text.toString().trim().ifBlank { "192.168.34.44" }
        val port = serverPortEditText.text.toString().trim().ifBlank { "8000" }
        return "http://$ip:$port"
    }

    private fun checkServerHealth() {
        val baseUrl = baseUrl()
        statusTextView.text = "Checking server..."
        Thread {
            try {
                val request = Request.Builder().url("$baseUrl/health").get().build()
                client.newCall(request).execute().use { response ->
                    val text = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        throw RuntimeException("HTTP ${response.code}: $text")
                    }
                    runOnUiThread {
                        statusTextView.text = "Server is reachable"
                        resultTextView.text = text
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusTextView.text = "Server check failed"
                    resultTextView.text = e.stackTraceToString()
                }
            }
        }.start()
    }

    private fun uploadLatestPhoto() {
        val photo = latestPhotoFile
        if (photo == null || !photo.exists()) {
            toast("Take a receipt photo first")
            return
        }
        val baseUrl = baseUrl()
        statusTextView.text = "Uploading receipt..."

        Thread {
            try {
                val body = MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("file", photo.name, photo.asRequestBody("image/jpeg".toMediaType()))
                    .build()
                val request = Request.Builder().url("$baseUrl/receipts/upload").post(body).build()
                client.newCall(request).execute().use { response ->
                    val text = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        throw RuntimeException(text)
                    }
                    val jobId = JSONObject(text).getString("job_id")
                    runOnUiThread {
                        resultTextView.text = text
                        statusTextView.text = "Uploaded. Polling job $jobId"
                    }
                    pollJob(baseUrl, jobId)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusTextView.text = "Upload failed"
                    resultTextView.text = e.stackTraceToString()
                }
            }
        }.start()
    }

    private fun pollJob(baseUrl: String, jobId: String) {
        Thread {
            try {
                var done = false
                while (!done) {
                    val req = Request.Builder().url("$baseUrl/jobs/$jobId").get().build()
                    client.newCall(req).execute().use { response ->
                        val text = response.body?.string().orEmpty()
                        val json = JSONObject(text)
                        val status = json.optString("status")
                        runOnUiThread {
                            resultTextView.text = text
                            statusTextView.text = "Job status: $status"
                        }
                        if (status == "complete" || status == "error") {
                            done = true
                        }
                    }
                    if (!done) {
                        Thread.sleep(1500)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusTextView.text = "Polling failed"
                    resultTextView.text = e.stackTraceToString()
                }
            }
        }.start()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
