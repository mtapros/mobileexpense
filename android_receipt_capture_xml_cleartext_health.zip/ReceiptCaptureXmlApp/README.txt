XML Android Receipt Capture App

This revision enables cleartext HTTP for local LAN testing and adds a Check Server button.
Use Check Server to call /health and verify the desktop API is running before taking or uploading a photo.

Default server IP: 192.168.34.44
Default port: 8000
